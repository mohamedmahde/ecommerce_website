<!DOCTYPE html>
<html>

<head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
        table {

            border: 2px solid skyblue;
            text-align: center;
        }

        th {
            background-color: skyblue;
            padding: 10px;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            color: white;
        }

        td {
            color: white;
            padding: 10px;
            border: 1px solid skyblue;
        }

        .table_center {
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>

<body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar Navigation end-->
    <div class="page-content">
        <div class="page-header">

            <div class="table_center">
                <table>
                    <tr>
                        <th>Customer Name</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Product Title</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Change Status</th>
                        <th>Print PDF</th>

                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->rec_address); ?></td>
                            <td><?php echo e($data->phone); ?></td>
                            <td><?php echo e($data->product->title); ?></td>
                            <td><?php echo e($data->product->price); ?></td>
                            <td><img width="100" src="products/<?php echo e($data->product->image); ?>" alt=""></td>
                            <td>
                                <?php if($data->status == 'in progress'): ?>

                                    <span style="color:red"><?php echo e($data->status); ?></span>

                                <?php elseif($data->status == 'one the way'): ?>

                                    <span style="color:green"><?php echo e($data->status); ?></span>

                                <?php else: ?>
                                    <span style="color:rgb(212, 226, 20)"><?php echo e($data->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(url('on_the_way', $data->id)); ?>">On The Way</a>
                                <a class="btn btn-success" href="<?php echo e(url('delivered', $data->id)); ?>">Delievered</a>
                            </td>

                            <td><a class="btn btn-secondary" href="">Print PDF</a></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo e(asset('admincss/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/popper.js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/jquery.cookie/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/js/charts-home.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/js/front.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel\ecommerce\resources\views/admin/view_orders.blade.php ENDPATH**/ ?>