<!DOCTYPE html>
<html>

<head>
    <?php echo $__env->make('home.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .dev_deg {

            display: flex;
            justify-content: center;
            align-items: center;
            margin: 60px;
        }

        table {
            border: 2px solid black;
            text-align: center;
            width: 800px;
        }

        th {
            border: 2px solid black;
            text-align: center;
            color: white;
            font: 20px;
            font-weight: bold;
            background-color: black;
        }

        td {

            border: 1px solid skyblue;
        }

        .cart_vlaue {

            text-align: center;
            margin-bottom: 50px;
            padding: 50px;
        }

        .order_deg {

            padding-right: 100px;
            margin-top: -50px;

        }
        label{

            display: inline-block;
            width: 150px;
        }
        .div_gap{
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="hero_area">
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        <div class="dev_deg">
            <div class="order_deg">
                <form action="<?php echo e(url('confirm_order')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="div_gap">
                        <label for="">Receiver Name</label>
                        <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">
                    </div>
                    <div class="div_gap">
                        <label for="">Receiver Address</label>
                        <textarea name="address" ><?php echo e(Auth::user()->address); ?></textarea>
                    </div>
                    <div class="div_gap">
                        <label for="">Receiver Phone</label>
                        <input type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>"> 
                    </div>
                    <div class="div_gap">
                        <input class="btn btn-primary" type="submit" value="place Order">
                    </div>
                </form>
            </div>
            <table>
                <tr>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                <?php
                $value = 0;
                
                ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cart->product->title); ?></td>
                        <td><?php echo e($cart->product->price); ?></td>
                        <td><img width="150" src="/products/<?php echo e($cart->product->image); ?>"></td>
                        <td><a class="btn btn-danger" href="<?php echo e(url('delete_cart', $cart->id)); ?>">Remove</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php
                $value = $value + $cart->product->price;
                
                ?>
            </table>

        </div>
        <div class="cart_vlaue">
            <h3>Total Value of cart is: <?php echo e($value); ?>LYD </h3>
        </div>


        <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\laravel\ecommerce\resources\views/home/mycart.blade.php ENDPATH**/ ?>