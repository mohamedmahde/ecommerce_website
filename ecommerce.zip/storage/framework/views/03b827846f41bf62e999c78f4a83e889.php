<!DOCTYPE html>
<html>

<head>
 <?php echo $__env->make('home.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <style>
    .div_center{

        display: flex;
        justify-content: center;
        align-items: center;
        padding: 30px;
    }
    .detail-box{

        padding:15px;
    }
 </style>
</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
 <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
  </div>


  

  
<section class="shop_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
           Products Details
        </h2>
      </div>
      <div class="row">
          
        <div class="col-md-12">
          <div class="box">
          
              <div class="div_center">
                <img width="400" src="/products/<?php echo e($data->image); ?>" alt="">
              </div>
              <div class="detail-box">
                <h6> <?php echo e($data->title); ?></h6>
                <h6> Price <span><?php echo e($data->price); ?>LYD </span>  </h6>
              </div>

              <div class="detail-box">
                <h6>Category:  <?php echo e($data->category); ?></h6>
                <h6> Available Quantity <span><?php echo e($data->quantity); ?> </span>  </h6>
              </div>
             
              <div class="detail-box">
               <p><?php echo e($data->descripton); ?> </p>  
              </div>
             
             
     
          </div>
        </div>




      </div>
     
    </div>
  </section>


   

  
<?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\laragon\www\laravel\ecommerce\resources\views/home/product_details.blade.php ENDPATH**/ ?>